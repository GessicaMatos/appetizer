package com.example.appetizer;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Mcdonalds_Menu extends AppCompatActivity {

    String[] mcdmenu ={"Big MAC","Mighty ANGUS",
            "BLT","FRIES","DRINKS"};

    int[] mcdImages = new int[]{R.drawable.bigmac,R.drawable.mightyangus,
            R.drawable.blt,R.drawable.mcdfries,R.drawable.drinks};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mcdonalds__menu);
        List<HashMap<String,String>> aList = new ArrayList<HashMap<String,String>>();

        for(int i=0;i<5;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("txt","" + mcdmenu[i]);
            hm.put("images", Integer.toString(mcdImages[i]) );
            aList.add(hm);
        }

        String[] from = { "images","txt"}; // Keys used in Hashmap
        int[] to = { R.id.image,R.id.mcdmenudetail}; // Ids of views in listview_layout

        // Instantiating an adapter to store each items
        // R.layout.listview_layout defines the layout of each item
        SimpleAdapter adapter = new SimpleAdapter
                (getBaseContext(), aList, R.layout.mcdmenudetail,
                        from, to);

        // Getting a reference to listview of activity_main.xml layout file
        ListView listView = ( ListView ) findViewById(R.id.mcdMenuList);

        // Setting the adapter to the listView
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.
                OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    View view, int position, long id) {
                switch(position){
                    case 0:
                        startActivity(new Intent(Mcdonalds_Menu.this, MCD_bigmac.class));
                        break;
                    case 1:
                        startActivity(new Intent(Mcdonalds_Menu.this, MCD_angus.class));
                        break;
                    case 2:
                        startActivity(new Intent(Mcdonalds_Menu.this, MCD_blt.class));
                        break;
                    case 3:
                        startActivity(new Intent(Mcdonalds_Menu.this, MCD_fries.class));
                        break;
                    case 4:
                        startActivity(new Intent(Mcdonalds_Menu.this, MCD_drinks.class));
                        break;



                }
            }
        });



    }
}

