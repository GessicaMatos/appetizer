package com.example.appetizer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {
    int pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setTitle(R.string.btnLogin);

        final EditText email = findViewById(R.id.editText);
        final EditText password = findViewById(R.id.editText2);
        Button btnLogin= findViewById(R.id.button);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // startActivity(new Intent(LoginActivity.this, UserOne.class))
            //pwd=Integer.parseInt(password.getText().toString());


            if(email.getText().toString().equals("rrsharma")&password.getText().toString().equals("1234"))
            {
                startActivity(new Intent(LoginActivity.this, UserOne.class));
            }
            if(email.getText().toString().equals("auppal")&password.getText().toString().equals("1234"))
            {
                startActivity(new Intent(LoginActivity.this, UserTwo.class));
            }
            if(email.getText().toString().equals("csethi")&password.getText().toString().equals("1234"))
            {
                startActivity(new Intent(LoginActivity.this, UserThree.class));
            }
            if(email.getText().toString().equals("gmatos")&password.getText().toString().equals("1234"))
            {
                startActivity(new Intent(LoginActivity.this, UserFour.class));
            }
            if(email.getText().toString().equals("mbashir")&password.getText().toString().equals("1234"))
            {
                startActivity(new Intent(LoginActivity.this, UserFive .class));
            }

            }
        });
    }

}
